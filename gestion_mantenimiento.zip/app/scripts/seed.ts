
import { PrismaClient } from '@prisma/client';
import { Decimal } from '@prisma/client/runtime/library';

const prisma = new PrismaClient();

// Datos realistas para empresas de transportes
const marcas = ['Toyota', 'Jungheinrich', 'Still', 'Linde', 'Hyster', 'Crown', 'BT', 'Yale'];
const modelos = {
  'Toyota': ['8FBCHU25', '8FBMHT20', '7FBMF25', '8FGCU32'],
  'Jungheinrich': ['EFG216', 'TFG316s', 'EJC110', 'EMC110'],
  'Still': ['RX70-22', 'EXV-SF14', 'FM-14', 'EGV14'],
  'Linde': ['H25T', 'E16P', 'T20SF', 'P250'],
  'Hyster': ['H2.5FT', 'E2.0XN', 'P1.8AC', 'J2.0XN'],
  'Crown': ['FC5252-50', 'PE4000-60', 'RC5500-30', 'WP3010-40'],
  'BT': ['LHM230', 'LPE250', 'SWE120L', 'LWE160'],
  'Yale': ['GLP25VX', 'ERP030VN', 'MSW040SEN', 'MCW020LEN']
};

const empresasAlquiler = [
  'Linde Material Handling',
  'TVH Equipment',
  'Carretillas Elevadoras Norte',
  'Alquiler Industrial Levante',
  'Manutención y Logística SL',
  'Elevadores Industriales Madrid',
  'Carretillas Cataluña',
  'Alquileres Logistics Pro'
];

const centrosLogisticos = [
  'Madrid - Coslada',
  'Barcelona - Mercabarna',
  'Valencia - Puerto',
  'Sevilla - Centro',
  'Zaragoza - Plaza',
  'Bilbao - Zona Franca',
  'Málaga - Guadalhorce',
  'Murcia - Espinardo'
];

const tiposAveria = [
  'Fallo motor',
  'Sistema hidráulico',
  'Frenos desgastados',
  'Batería agotada',
  'Cadenas elevación',
  'Ruedas desgaste',
  'Sistema eléctrico',
  'Mástil elevador',
  'Transmisión',
  'Dirección asistida',
  'Válvulas hidráulicas',
  'Sensor peso',
  'Alarma reversa',
  'Luces trabajo',
  'Asiento conductor'
];

function generarNumeroSerie(): string {
  const prefix = ['TYT', 'JUN', 'STL', 'LIN', 'HYS', 'CRW', 'BT', 'YAL'];
  const randomPrefix = prefix[Math.floor(Math.random() * prefix.length)];
  const numero = Math.floor(Math.random() * 9000) + 1000;
  return `${randomPrefix}${numero}`;
}

function obtenerFechaAleatoria(diasAtras: number): Date {
  const fecha = new Date();
  fecha.setDate(fecha.getDate() - Math.floor(Math.random() * diasAtras));
  return fecha;
}

function obtenerCosteAleatorio(min: number, max: number): Decimal {
  const coste = Math.random() * (max - min) + min;
  return new Decimal(coste.toFixed(2));
}

async function seed() {
  console.log('🌱 Iniciando seed de la base de datos...');

  try {
    // Limpiar datos existentes
    await prisma.averia.deleteMany({});
    await prisma.maquina.deleteMany({});
    console.log('✅ Base de datos limpiada');

    // Crear 80 máquinas realistas
    console.log('📦 Creando máquinas...');
    const maquinas = [];
    
    for (let i = 0; i < 80; i++) {
      const marca = marcas[Math.floor(Math.random() * marcas.length)];
      const modelosDisponibles = modelos[marca as keyof typeof modelos];
      const modelo = modelosDisponibles[Math.floor(Math.random() * modelosDisponibles.length)];
      
      const maquina = await prisma.maquina.create({
        data: {
          numeroSerie: generarNumeroSerie(),
          marca,
          modelo,
          empresaAlquila: empresasAlquiler[Math.floor(Math.random() * empresasAlquiler.length)],
          costeAlquiler: obtenerCosteAleatorio(180, 450), // Entre 180-450€/mes
          ubicacion: centrosLogisticos[Math.floor(Math.random() * centrosLogisticos.length)],
          fechaCreacion: obtenerFechaAleatoria(365 * 2), // Últimos 2 años
        }
      });
      
      maquinas.push(maquina);
      
      if ((i + 1) % 20 === 0) {
        console.log(`   ✓ Creadas ${i + 1}/80 máquinas`);
      }
    }
    console.log('✅ 80 máquinas creadas correctamente');

    // Crear averías realistas (aproximadamente 2-3 averías por máquina)
    console.log('🔧 Creando averías...');
    const totalAverias = Math.floor(Math.random() * 80) + 120; // Entre 120-200 averías
    
    for (let i = 0; i < totalAverias; i++) {
      const maquinaAleatoria = maquinas[Math.floor(Math.random() * maquinas.length)];
      const tipoAveria = tiposAveria[Math.floor(Math.random() * tiposAveria.length)];
      
      // Generar costes realistas según el tipo de avería
      let costeMin = 50, costeMax = 200;
      if (tipoAveria.includes('motor') || tipoAveria.includes('transmisión')) {
        costeMin = 300; costeMax = 1200;
      } else if (tipoAveria.includes('hidráulico') || tipoAveria.includes('mástil')) {
        costeMin = 150; costeMax = 600;
      } else if (tipoAveria.includes('batería')) {
        costeMin = 200; costeMax = 800;
      }
      
      const descripciones = {
        'Fallo motor': 'Motor diésel presenta pérdida de potencia y humo excesivo',
        'Sistema hidráulico': 'Fuga de aceite hidráulico en cilindro principal',
        'Frenos desgastados': 'Pastillas de freno completamente desgastadas, requiere cambio',
        'Batería agotada': 'Batería no mantiene carga, vida útil agotada',
        'Cadenas elevación': 'Cadena de elevación presenta eslabones desgastados',
        'Ruedas desgaste': 'Neumáticos con desgaste irregular, requiere alineación',
        'Sistema eléctrico': 'Fallo en cableado principal, intermitencia en controles',
        'Mástil elevador': 'Mástil no eleva correctamente, problema en cilindros',
        'Transmisión': 'Cambio de marchas defectuoso, requiere reparación',
        'Dirección asistida': 'Dirección endurecida, problema en bomba hidráulica',
        'Válvulas hidráulicas': 'Válvula de control pegada, elevación lenta',
        'Sensor peso': 'Sensor de sobrecarga descalibrado',
        'Alarma reversa': 'Alarma acústica de marcha atrás no funciona',
        'Luces trabajo': 'Foco de trabajo LED fundido',
        'Asiento conductor': 'Tapizado del asiento roto, requiere cambio'
      };
      
      await prisma.averia.create({
        data: {
          maquinaId: maquinaAleatoria.id,
          fecha: obtenerFechaAleatoria(365), // Último año
          tipoAveria,
          coste: obtenerCosteAleatorio(costeMin, costeMax),
          descripcion: descripciones[tipoAveria as keyof typeof descripciones] || 'Mantenimiento general requerido'
        }
      });
      
      if ((i + 1) % 30 === 0) {
        console.log(`   ✓ Creadas ${i + 1}/${totalAverias} averías`);
      }
    }
    
    console.log(`✅ ${totalAverias} averías creadas correctamente`);
    
    // Mostrar estadísticas
    const totalMaquinas = await prisma.maquina.count();
    const totalAveriasCreadas = await prisma.averia.count();
    const costeTotal = await prisma.averia.aggregate({
      _sum: { coste: true }
    });
    
    console.log('\n📊 ESTADÍSTICAS DEL SEED:');
    console.log(`   • Total máquinas: ${totalMaquinas}`);
    console.log(`   • Total averías: ${totalAveriasCreadas}`);
    console.log(`   • Coste total averías: €${costeTotal._sum.coste?.toString() || '0'}`);
    console.log(`   • Promedio averías por máquina: ${(totalAveriasCreadas / totalMaquinas).toFixed(1)}`);
    
    console.log('\n🎉 ¡Seed completado exitosamente!');
    
  } catch (error) {
    console.error('❌ Error durante el seed:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

seed().catch((error) => {
  console.error('💥 Seed falló:', error);
  process.exit(1);
});
