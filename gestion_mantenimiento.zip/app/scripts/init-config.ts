

import { PrismaClient } from '@prisma/client';
import dotenv from 'dotenv';

dotenv.config();
const prisma = new PrismaClient();

async function initializeConfig() {
  try {
    // Verificar si ya existe configuración
    const existingConfig = await prisma.configuracion.findFirst();
    
    if (!existingConfig) {
      await prisma.configuracion.create({
        data: {
          nombreEmpresa: 'Mi Empresa de Transporte',
          colorPrimario: '#3B82F6',
          colorSecundario: '#1E40AF',
          direccion: 'Calle Principal, 123, Madrid, 28001',
          telefono: '+34 911 123 456',
          email: 'contacto@miempresa.com',
          sitioWeb: 'https://www.miempresa.com'
        }
      });
      console.log('✅ Configuración por defecto creada');
    } else {
      console.log('✅ Configuración ya existe');
    }
  } catch (error) {
    console.error('Error al inicializar configuración:', error);
  } finally {
    await prisma.$disconnect();
  }
}

initializeConfig();
