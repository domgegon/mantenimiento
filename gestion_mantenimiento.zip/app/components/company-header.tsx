

'use client';

import { useConfig } from '@/hooks/use-config';
import Image from 'next/image';
import { Building } from 'lucide-react';

export function CompanyHeader() {
  const { config, isLoading } = useConfig();

  if (isLoading) {
    return (
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-6 w-48 bg-gray-200 rounded animate-pulse"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border-b border-gray-200 px-6 py-3 shadow-sm">
      <div className="flex items-center gap-3">
        {config?.logoUrl ? (
          <div className="w-8 h-8 relative overflow-hidden rounded">
            <Image
              src={config.logoUrl}
              alt={`Logo de ${config.nombreEmpresa}`}
              fill
              style={{ objectFit: 'contain' }}
              className="rounded"
            />
          </div>
        ) : (
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
            <Building className="w-5 h-5 text-white" />
          </div>
        )}
        <div>
          <h1 className="text-lg font-semibold text-gray-900">
            {config?.nombreEmpresa || 'Mi Empresa de Transporte'}
          </h1>
          <p className="text-sm text-gray-500">Sistema de Gestión Logística</p>
        </div>
      </div>
    </div>
  );
}
