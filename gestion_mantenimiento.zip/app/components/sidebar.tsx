
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  BarChart3,
  Package,
  Wrench,
  Menu,
  X,
  Truck,
  TrendingUp,
  AlertTriangle,
  FileText,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useConfig } from '@/hooks/use-config';
import Image from 'next/image';

const navigationItems = [
  {
    title: 'Dashboard',
    href: '/',
    icon: BarChart3,
    description: 'Panel de control principal'
  },
  {
    title: 'Inventario',
    href: '/inventario',
    icon: Package,
    description: 'Gestión de máquinas'
  },
  {
    title: 'Averías',
    href: '/averias',
    icon: Wrench,
    description: 'Registro de averías'
  },
  {
    title: 'Análisis',
    href: '/analisis',
    icon: TrendingUp,
    description: 'Análisis avanzado'
  },
  {
    title: 'Reportes',
    href: '/reportes',
    icon: FileText,
    description: 'Informes y exportación'
  },
  {
    title: 'Configuración',
    href: '/configuracion',
    icon: Settings,
    description: 'Configuración de empresa'
  }
];

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const pathname = usePathname();
  const { config } = useConfig();

  return (
    <div className={cn(
      "relative flex flex-col bg-gradient-to-b from-slate-900 to-slate-800 text-white transition-all duration-300 shadow-2xl",
      isCollapsed ? "w-16" : "w-72"
    )}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-700">
        <div className={cn("flex items-center space-x-3", isCollapsed && "justify-center")}>
          <div className="flex items-center justify-center w-10 h-10 bg-blue-600 rounded-lg overflow-hidden">
            {config?.logoUrl ? (
              <Image
                src={config.logoUrl}
                alt="Logo empresa"
                width={40}
                height={40}
                style={{ objectFit: 'contain' }}
                className="rounded-lg"
              />
            ) : (
              <Truck className="w-6 h-6 text-white" />
            )}
          </div>
          {!isCollapsed && (
            <div>
              <h1 className="text-lg font-bold">{config?.nombreEmpresa || 'Gestión Logística'}</h1>
              <p className="text-xs text-slate-400">Sistema de Inventario</p>
            </div>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="text-white hover:bg-slate-700"
        >
          {isCollapsed ? <Menu className="w-5 h-5" /> : <X className="w-5 h-5" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center space-x-3 px-3 py-3 rounded-lg transition-all duration-200 group",
                isActive 
                  ? "bg-blue-600 text-white shadow-lg" 
                  : "text-slate-300 hover:bg-slate-700 hover:text-white",
                isCollapsed && "justify-center px-2"
              )}
            >
              <Icon className={cn(
                "w-5 h-5 transition-transform group-hover:scale-110",
                isActive && "text-white"
              )} />
              {!isCollapsed && (
                <div>
                  <span className="font-medium">{item.title}</span>
                  <p className={cn(
                    "text-xs transition-colors",
                    isActive ? "text-blue-100" : "text-slate-400"
                  )}>
                    {item.description}
                  </p>
                </div>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Stats Summary */}
      {!isCollapsed && (
        <div className="p-4 border-t border-slate-700">
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Estado del Sistema</span>
              <span className="text-green-400 flex items-center gap-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                Activo
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-800 p-2 rounded">
                <p className="text-slate-400">Máquinas</p>
                <p className="text-white font-bold">80</p>
              </div>
              <div className="bg-slate-800 p-2 rounded">
                <p className="text-slate-400">Averías</p>
                <p className="text-white font-bold">188</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
