-- CreateTable
CREATE TABLE "configuracion" (
    "id" TEXT NOT NULL,
    "nombre_empresa" TEXT NOT NULL DEFAULT 'Mi Empresa',
    "logo_url" TEXT,
    "color_primario" TEXT NOT NULL DEFAULT '#3B82F6',
    "color_secundario" TEXT NOT NULL DEFAULT '#1E40AF',
    "direccion" TEXT,
    "telefono" TEXT,
    "email" TEXT,
    "sitio_web" TEXT,
    "fecha_creacion" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "fecha_actualizacion" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "configuracion_pkey" PRIMARY KEY ("id")
);
