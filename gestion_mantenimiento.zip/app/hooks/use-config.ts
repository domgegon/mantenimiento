

'use client';

import { useState, useEffect, useCallback } from 'react';

interface Configuracion {
  id: string;
  nombreEmpresa: string;
  logoUrl?: string;
  colorPrimario: string;
  colorSecundario: string;
  direccion?: string;
  telefono?: string;
  email?: string;
  sitioWeb?: string;
}

export function useConfig() {
  const [config, setConfig] = useState<Configuracion | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const cargarConfiguracion = useCallback(async () => {
    try {
      console.log('Cargando configuración...');
      const response = await fetch('/api/configuracion');
      console.log('Respuesta API configuración:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Datos configuración cargados:', data);
        setConfig(data);
      } else {
        console.error('Error en respuesta:', response.status);
      }
    } catch (error) {
      console.error('Error al cargar configuración:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    cargarConfiguracion();
  }, [cargarConfiguracion]);

  return { config, isLoading, recargar: cargarConfiguracion };
}
