
# Sistema de Gestión Logística

Una aplicación web moderna para la gestión de inventario de máquinas de alquiler y seguimiento de reparaciones.

## Características

- 🏢 **Gestión de Inventario**: Administra máquinas de alquiler con información detallada
- 🔧 **Registro de Averías**: Control completo de reparaciones y mantenimiento
- 📊 **Reportes y Análisis**: Visualización de costos y estadísticas
- ⚙️ **Configuración Personalizable**: Logo, colores y datos de empresa
- 🔐 **Sistema de Autenticación**: Acceso seguro con NextAuth.js

## Tecnologías Utilizadas

- **Frontend**: Next.js 14, React, TypeScript, Tailwind CSS
- **Backend**: API Routes de Next.js
- **Base de Datos**: PostgreSQL con Prisma ORM
- **Autenticación**: NextAuth.js
- **UI Components**: Radix UI, Shadcn/ui
- **Gráficos**: Chart.js, Recharts

## Despliegue

Esta aplicación está optimizada para desplegarse en Vercel con base de datos PostgreSQL.

### Variables de Entorno Necesarias:

```
DATABASE_URL="postgresql://..."
NEXTAUTH_URL="https://tu-dominio.vercel.app"
NEXTAUTH_SECRET="tu-secret-aleatorio"
```

## Funcionalidades

### 📦 Inventario
- Agregar/editar máquinas
- Información de contratos y fechas de renovación
- Filtros y búsqueda avanzada
- Estados de máquinas

### 🔧 Averías
- Registro detallado de reparaciones
- Tipos de avería personalizables
- Control de costos
- Seguimiento temporal

### 📈 Reportes
- Métricas de costos por máquina
- Distribución por centros logísticos
- Exportación a CSV
- Gráficos interactivos

### ⚙️ Configuración
- Logo personalizable
- Colores de marca
- Información de empresa
- Datos de contacto

## Estructura del Proyecto

```
app/
├── app/                 # Páginas y API routes
├── components/          # Componentes reutilizables
├── lib/                # Utilidades y configuración
├── prisma/             # Esquema de base de datos
├── public/             # Archivos estáticos
└── styles/             # Estilos globales
```
