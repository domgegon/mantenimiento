
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET() {
  try {
    // Estadísticas básicas
    const totalMaquinas = await prisma.maquina.count();
    const totalAverias = await prisma.averia.count();
    
    // Coste total de averías
    const costeResult = await prisma.averia.aggregate({
      _sum: { coste: true }
    });
    const costeTotal = Number(costeResult._sum?.coste || 0);

    // Averías últimos 30 días
    const fecha30Dias = new Date();
    fecha30Dias.setDate(fecha30Dias.getDate() - 30);
    
    const averiasRecientes = await prisma.averia.count({
      where: {
        fecha: {
          gte: fecha30Dias
        }
      }
    });

    // Máquinas con averías
    const maquinasConAverias = await prisma.maquina.count({
      where: {
        averias: {
          some: {}
        }
      }
    });

    // Coste por centro logístico
    const costePorCentro = await prisma.$queryRaw`
      SELECT 
        m.ubicacion as name,
        CAST(SUM(a.coste) as DECIMAL(10,2)) as value
      FROM maquinas m
      INNER JOIN averias a ON m.id = a.maquina_id
      GROUP BY m.ubicacion
      ORDER BY value DESC
      LIMIT 8
    ` as { name: string; value: number }[];

    // Tipos de averías más comunes
    const tipoAverias = await prisma.$queryRaw`
      SELECT 
        tipo_averia as name,
        COUNT(*) as value
      FROM averias
      GROUP BY tipo_averia
      ORDER BY value DESC
      LIMIT 6
    ` as { name: string; value: number }[];

    // Marcas con más averías
    const marcasMasAverias = await prisma.$queryRaw`
      SELECT 
        m.marca as name,
        COUNT(a.id) as value
      FROM maquinas m
      INNER JOIN averias a ON m.id = a.maquina_id
      GROUP BY m.marca
      ORDER BY value DESC
      LIMIT 5
    ` as { name: string; value: number }[];

    // Tendencia mensual de averías
    const tendenciaAverias = await prisma.$queryRaw`
      SELECT 
        TO_CHAR(fecha, 'MM-YYYY') as name,
        COUNT(*) as value
      FROM averias
      WHERE fecha >= NOW() - INTERVAL '12 months'
      GROUP BY TO_CHAR(fecha, 'MM-YYYY'), DATE_TRUNC('month', fecha)
      ORDER BY DATE_TRUNC('month', fecha)
      LIMIT 12
    ` as { name: string; value: number }[];

    // Formatear datos para los gráficos
    const response = {
      stats: {
        totalMaquinas,
        totalAverias,
        costeTotal,
        costetMensual: Math.round(costeTotal / 12), // Estimado mensual
        averiasUltimos30Dias: averiasRecientes,
        maquinasConAverias
      },
      charts: {
        costePorCentro: costePorCentro?.map?.(item => ({
          name: item?.name || '',
          value: Number(item?.value || 0)
        })) || [],
        tipoAverias: tipoAverias?.map?.(item => ({
          name: item?.name || '',
          value: Number(item?.value || 0)
        })) || [],
        marcasMasAverias: marcasMasAverias?.map?.(item => ({
          name: item?.name || '',
          value: Number(item?.value || 0)
        })) || [],
        tendenciaAverias: tendenciaAverias?.map?.(item => ({
          name: item?.name || '',
          value: Number(item?.value || 0)
        })) || []
      }
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('Error en dashboard API:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
