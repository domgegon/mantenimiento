
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET() {
  try {
    const maquinas = await prisma.maquina.findMany({
      include: {
        _count: {
          select: { averias: true }
        }
      },
      orderBy: {
        fechaCreacion: 'desc'
      }
    });

    // Convertir Decimal a number para serialización JSON
    const maquinasSerializadas = maquinas?.map?.(maquina => ({
      ...maquina,
      costeAlquiler: Number(maquina?.costeAlquiler || 0)
    })) || [];

    return NextResponse.json({ maquinas: maquinasSerializadas });
  } catch (error) {
    console.error('Error fetching maquinas:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: Request) {
  try {
    const body = await request?.json?.();
    
    const maquina = await prisma.maquina.create({
      data: {
        numeroSerie: body?.numeroSerie,
        marca: body?.marca,
        modelo: body?.modelo,
        empresaAlquila: body?.empresaAlquila,
        costeAlquiler: body?.costeAlquiler,
        ubicacion: body?.ubicacion,
        contrato: body?.contrato || null,
        fechaRenovacion: body?.fechaRenovacion ? new Date(body.fechaRenovacion) : null
      }
    });

    return NextResponse.json({ maquina });
  } catch (error) {
    console.error('Error creating maquina:', error);
    return NextResponse.json(
      { error: 'Error al crear la máquina' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
