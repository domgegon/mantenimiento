
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id;
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requerido' }, 
        { status: 400 }
      );
    }

    const maquina = await prisma.maquina.findUnique({
      where: { id }
    });

    if (!maquina) {
      return NextResponse.json(
        { error: 'Máquina no encontrada' }, 
        { status: 404 }
      );
    }

    // Convertir Decimal a number para serialización JSON
    const maquinaSerializada = {
      ...maquina,
      costeAlquiler: Number(maquina?.costeAlquiler || 0)
    };

    return NextResponse.json({ maquina: maquinaSerializada });
  } catch (error) {
    console.error('Error fetching maquina:', error);
    return NextResponse.json(
      { error: 'Error al obtener la máquina' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id;
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requerido' }, 
        { status: 400 }
      );
    }

    await prisma.maquina.delete({
      where: { id }
    });

    return NextResponse.json({ message: 'Máquina eliminada correctamente' });
  } catch (error) {
    console.error('Error deleting maquina:', error);
    return NextResponse.json(
      { error: 'Error al eliminar la máquina' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id;
    const body = await request?.json?.();
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requerido' }, 
        { status: 400 }
      );
    }

    const maquina = await prisma.maquina.update({
      where: { id },
      data: {
        numeroSerie: body?.numeroSerie,
        marca: body?.marca,
        modelo: body?.modelo,
        empresaAlquila: body?.empresaAlquila,
        costeAlquiler: body?.costeAlquiler,
        ubicacion: body?.ubicacion,
        contrato: body?.contrato || null,
        fechaRenovacion: body?.fechaRenovacion ? new Date(body.fechaRenovacion) : null
      }
    });

    return NextResponse.json({ maquina });
  } catch (error) {
    console.error('Error updating maquina:', error);
    return NextResponse.json(
      { error: 'Error al actualizar la máquina' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
