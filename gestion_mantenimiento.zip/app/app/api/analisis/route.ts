
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET() {
  try {
    // Obtener datos básicos
    const totalMaquinas = await prisma.maquina.count();
    const totalAverias = await prisma.averia.count();
    
    // Coste total de averías
    const costeResult = await prisma.averia.aggregate({
      _sum: { coste: true }
    });
    const costeTotal = Number(costeResult._sum?.coste || 0);

    // Máquinas con averías
    const maquinasConAverias = await prisma.maquina.count({
      where: {
        averias: {
          some: {}
        }
      }
    });

    // Calcular KPIs de eficiencia
    const disponibilidad = totalMaquinas > 0 ? ((totalMaquinas - maquinasConAverias) / totalMaquinas) * 100 : 100;
    const tiempoPromedioReparacion = 3.5; // Estimado en días
    const costePorMaquina = totalMaquinas > 0 ? costeTotal / totalMaquinas : 0;
    const frecuenciaAverias = totalMaquinas > 0 ? totalAverias / totalMaquinas : 0;

    // Evolución mensual de costes
    const costeMensual = await prisma.$queryRaw`
      SELECT 
        TO_CHAR(fecha, 'MM/YY') as mes,
        CAST(SUM(coste) as DECIMAL(10,2)) as coste,
        COUNT(*) as cantidad
      FROM averias
      WHERE fecha >= NOW() - INTERVAL '12 months'
      GROUP BY TO_CHAR(fecha, 'MM/YY'), DATE_TRUNC('month', fecha)
      ORDER BY DATE_TRUNC('month', fecha)
      LIMIT 12
    ` as { mes: string; coste: number; cantidad: number }[];

    // Eficiencia por centro
    const eficienciaPorCentro = await prisma.$queryRaw`
      SELECT 
        m.ubicacion as centro,
        CAST(AVG(CASE WHEN a.id IS NULL THEN 100 ELSE 85 END) as DECIMAL(5,2)) as disponibilidad,
        CAST(COALESCE(SUM(a.coste), 0) as DECIMAL(10,2)) as coste
      FROM maquinas m
      LEFT JOIN averias a ON m.id = a.maquina_id
      GROUP BY m.ubicacion
      ORDER BY coste DESC
      LIMIT 8
    ` as { centro: string; disponibilidad: number; coste: number }[];

    // Centros más costosos
    const centrosMasCostosos = await prisma.$queryRaw`
      SELECT 
        m.ubicacion as nombre,
        CAST(SUM(a.coste) as DECIMAL(10,2)) as coste,
        COUNT(a.id) as averias
      FROM maquinas m
      INNER JOIN averias a ON m.id = a.maquina_id
      GROUP BY m.ubicacion
      ORDER BY coste DESC
      LIMIT 5
    ` as { nombre: string; coste: number; averias: number }[];

    // Máquinas problemáticas
    const maquinasProblematicas = await prisma.$queryRaw`
      SELECT 
        m.numero_serie as "numeroSerie",
        m.marca,
        COUNT(a.id) as averias,
        CAST(SUM(a.coste) as DECIMAL(10,2)) as coste
      FROM maquinas m
      INNER JOIN averias a ON m.id = a.maquina_id
      GROUP BY m.id, m.numero_serie, m.marca
      ORDER BY averias DESC, coste DESC
      LIMIT 5
    ` as { numeroSerie: string; marca: string; averias: number; coste: number }[];

    // Tipos de averías críticas
    const tiposAveriasCriticas = await prisma.$queryRaw`
      SELECT 
        tipo_averia as tipo,
        COUNT(*) as frecuencia,
        CAST(AVG(coste) as DECIMAL(10,2)) as "costePromedio"
      FROM averias
      GROUP BY tipo_averia
      ORDER BY frecuencia DESC, "costePromedio" DESC
      LIMIT 5
    ` as { tipo: string; frecuencia: number; costePromedio: number }[];

    // Correlación edad-averías (simulada)
    const correlacionEdadAverias = [
      { edad: 1, averias: 2, coste: 180 },
      { edad: 2, averias: 3, coste: 250 },
      { edad: 3, averias: 4, coste: 320 },
      { edad: 4, averias: 6, coste: 480 },
      { edad: 5, averias: 8, coste: 650 }
    ];

    // Predicción de costes (simulada)
    const prediccionCostes = [
      { mes: 'Ene', real: 2500, prediccion: 2450 },
      { mes: 'Feb', real: 2800, prediccion: 2750 },
      { mes: 'Mar', real: 3200, prediccion: 3100 },
      { mes: 'Abr', real: 2900, prediccion: 3000 },
      { mes: 'May', real: 3400, prediccion: 3350 }
    ];

    const response = {
      eficiencia: {
        disponibilidad,
        tiempoPromedioReparacion,
        costePorMaquina,
        frecuenciaAverias
      },
      tendencias: {
        costeMensual: costeMensual?.map?.(item => ({
          mes: item?.mes || '',
          coste: Number(item?.coste || 0),
          cantidad: Number(item?.cantidad || 0)
        })) || [],
        eficienciaPorCentro: eficienciaPorCentro?.map?.(item => ({
          centro: item?.centro || '',
          disponibilidad: Number(item?.disponibilidad || 0),
          coste: Number(item?.coste || 0)
        })) || [],
        correlacionEdadAverias,
        prediccionCostes
      },
      rankings: {
        centrosMasCostosos: centrosMasCostosos?.map?.(item => ({
          nombre: item?.nombre || '',
          coste: Number(item?.coste || 0),
          averias: Number(item?.averias || 0)
        })) || [],
        maquinasProblematicas: maquinasProblematicas?.map?.(item => ({
          numeroSerie: item?.numeroSerie || '',
          marca: item?.marca || '',
          averias: Number(item?.averias || 0),
          coste: Number(item?.coste || 0)
        })) || [],
        tiposAveriasCriticas: tiposAveriasCriticas?.map?.(item => ({
          tipo: item?.tipo || '',
          frecuencia: Number(item?.frecuencia || 0),
          costePromedio: Number(item?.costePromedio || 0)
        })) || []
      }
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('Error en análisis API:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
