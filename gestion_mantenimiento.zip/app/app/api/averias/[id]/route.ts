
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id;
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requerido' }, 
        { status: 400 }
      );
    }

    await prisma.averia.delete({
      where: { id }
    });

    return NextResponse.json({ message: 'Avería eliminada correctamente' });
  } catch (error) {
    console.error('Error deleting averia:', error);
    return NextResponse.json(
      { error: 'Error al eliminar la avería' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const id = params?.id;
    const body = await request?.json?.();
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requerido' }, 
        { status: 400 }
      );
    }

    const averia = await prisma.averia.update({
      where: { id },
      data: {
        fecha: new Date(body?.fecha),
        tipoAveria: body?.tipoAveria,
        coste: body?.coste,
        descripcion: body?.descripcion
      },
      include: {
        maquina: {
          select: {
            numeroSerie: true,
            marca: true,
            modelo: true,
            ubicacion: true
          }
        }
      }
    });

    return NextResponse.json({ averia });
  } catch (error) {
    console.error('Error updating averia:', error);
    return NextResponse.json(
      { error: 'Error al actualizar la avería' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
