
import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

export const dynamic = "force-dynamic";

const prisma = new PrismaClient();

export async function GET() {
  try {
    const averias = await prisma.averia.findMany({
      include: {
        maquina: {
          select: {
            numeroSerie: true,
            marca: true,
            modelo: true,
            ubicacion: true
          }
        }
      },
      orderBy: {
        fecha: 'desc'
      }
    });

    // Convertir Decimal a number para serialización JSON
    const averiasSerializadas = averias?.map?.(averia => ({
      ...averia,
      coste: Number(averia?.coste || 0)
    })) || [];

    return NextResponse.json({ averias: averiasSerializadas });
  } catch (error) {
    console.error('Error fetching averias:', error);
    return NextResponse.json(
      { error: 'Error interno del servidor' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: Request) {
  try {
    const body = await request?.json?.();
    
    const averia = await prisma.averia.create({
      data: {
        maquinaId: body?.maquinaId,
        fecha: new Date(body?.fecha),
        tipoAveria: body?.tipoAveria,
        coste: body?.coste,
        descripcion: body?.descripcion
      },
      include: {
        maquina: {
          select: {
            numeroSerie: true,
            marca: true,
            modelo: true,
            ubicacion: true
          }
        }
      }
    });

    return NextResponse.json({ averia });
  } catch (error) {
    console.error('Error creating averia:', error);
    return NextResponse.json(
      { error: 'Error al crear la avería' }, 
      { status: 500 }
    );
  } finally {
    await prisma.$disconnect();
  }
}
