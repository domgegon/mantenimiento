

import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  try {
    let config = await prisma.configuracion.findFirst();
    
    if (!config) {
      // Crear configuración por defecto si no existe
      config = await prisma.configuracion.create({
        data: {
          nombreEmpresa: 'Mi Empresa de Transporte',
          colorPrimario: '#3B82F6',
          colorSecundario: '#1E40AF'
        }
      });
    }
    
    return NextResponse.json(config);
  } catch (error) {
    console.error('Error al obtener configuración:', error);
    return NextResponse.json({ error: 'Error interno del servidor' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    console.log('PUT /api/configuracion - Iniciando...');
    
    // Obtener y validar datos
    const data = await request.json();
    console.log('Datos recibidos:', JSON.stringify(data, null, 2));
    
    // Validación básica
    if (!data.nombreEmpresa || typeof data.nombreEmpresa !== 'string' || !data.nombreEmpresa.trim()) {
      console.error('Validación fallida: nombreEmpresa requerido');
      return NextResponse.json({ error: 'El nombre de la empresa es requerido' }, { status: 400 });
    }

    // Limpiar y preparar datos
    const cleanData = {
      nombreEmpresa: data.nombreEmpresa.trim(),
      logoUrl: data.logoUrl || null,
      colorPrimario: data.colorPrimario || '#3B82F6',
      colorSecundario: data.colorSecundario || '#1E40AF',
      direccion: data.direccion?.trim() || null,
      telefono: data.telefono?.trim() || null,
      email: data.email?.trim() || null,
      sitioWeb: data.sitioWeb?.trim() || null
    };

    console.log('Datos limpios:', JSON.stringify(cleanData, null, 2));
    
    let config = await prisma.configuracion.findFirst();
    console.log('Configuración existente:', config ? `ID: ${config.id}` : 'No existe');
    
    if (!config) {
      console.log('Creando nueva configuración...');
      config = await prisma.configuracion.create({
        data: cleanData
      });
      console.log('Configuración creada:', config.id);
    } else {
      console.log('Actualizando configuración existente...');
      config = await prisma.configuracion.update({
        where: { id: config.id },
        data: cleanData
      });
      console.log('Configuración actualizada:', config.id);
    }
    
    console.log('Configuración final:', JSON.stringify(config, null, 2));
    return NextResponse.json(config);
    
  } catch (error) {
    console.error('Error completo al actualizar configuración:');
    console.error('Error object:', error);
    console.error('Error message:', error instanceof Error ? error.message : 'Unknown error');
    console.error('Error stack:', error instanceof Error ? error.stack : 'No stack');
    
    // Verificar si es un error de Prisma
    if (error && typeof error === 'object' && 'code' in error) {
      console.error('Error de Prisma - código:', (error as any).code);
      console.error('Error de Prisma - meta:', (error as any).meta);
    }
    
    const errorMessage = error instanceof Error ? error.message : 'Error interno del servidor';
    return NextResponse.json({ 
      error: errorMessage,
      details: process.env.NODE_ENV === 'development' ? error : undefined
    }, { status: 500 });
  }
}
