

'use client';

import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/main-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { 
  Building, 
  Upload, 
  Palette, 
  Save, 
  Mail, 
  Phone, 
  Globe, 
  MapPin,
  ImageIcon,
  Loader2
} from 'lucide-react';
import Image from 'next/image';

interface Configuracion {
  id: string;
  nombreEmpresa: string;
  logoUrl?: string;
  colorPrimario: string;
  colorSecundario: string;
  direccion?: string;
  telefono?: string;
  email?: string;
  sitioWeb?: string;
}

export default function ConfiguracionPage() {
  const [config, setConfig] = useState<Configuracion | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    cargarConfiguracion();
  }, []);

  const cargarConfiguracion = async () => {
    try {
      console.log('Cargando configuración desde página...');
      const response = await fetch('/api/configuracion');
      console.log('Estado de respuesta:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Datos recibidos:', data);
        setConfig(data);
      } else {
        console.error('Error al cargar configuración:', response.status);
        toast({
          title: 'Error',
          description: 'No se pudo cargar la configuración',
          variant: 'destructive'
        });
      }
    } catch (error) {
      console.error('Error en fetch:', error);
      toast({
        title: 'Error',
        description: 'Error de conexión al cargar la configuración',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: keyof Configuracion, value: string) => {
    if (config) {
      setConfig({
        ...config,
        [field]: value
      });
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validar tipo de archivo
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Error',
        description: 'Por favor, selecciona un archivo de imagen',
        variant: 'destructive'
      });
      return;
    }

    // Validar tamaño (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'Error',
        description: 'La imagen debe ser menor a 5MB',
        variant: 'destructive'
      });
      return;
    }

    setIsUploading(true);

    try {
      console.log('Subiendo archivo:', file.name, file.size);
      
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });

      console.log('Respuesta upload status:', response.status);

      if (response.ok) {
        const data = await response.json();
        console.log('URL del logo:', data.url);
        
        handleInputChange('logoUrl', data.url);
        toast({
          title: 'Éxito',
          description: 'Logo subido correctamente'
        });
      } else {
        const errorText = await response.text();
        console.error('Error uploading file:', errorText);
        throw new Error(`Error ${response.status}: ${errorText}`);
      }
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'No se pudo subir el logo',
        variant: 'destructive'
      });
    } finally {
      setIsUploading(false);
      // Limpiar el input para permitir subir el mismo archivo otra vez si es necesario
      event.target.value = '';
    }
  };

  const handleSave = async () => {
    if (!config) {
      toast({
        title: 'Error',
        description: 'No hay configuración para guardar',
        variant: 'destructive'
      });
      return;
    }

    setSaving(true);

    try {
      console.log('Guardando configuración:', JSON.stringify(config, null, 2));
      
      // Validar campos requeridos
      if (!config.nombreEmpresa?.trim()) {
        throw new Error('El nombre de la empresa es requerido');
      }

      // Preparar datos para enviar
      const dataToSave = {
        ...config,
        nombreEmpresa: config.nombreEmpresa.trim(),
        email: config.email?.trim() || null,
        telefono: config.telefono?.trim() || null,
        direccion: config.direccion?.trim() || null,
        sitioWeb: config.sitioWeb?.trim() || null
      };

      console.log('Datos a enviar:', JSON.stringify(dataToSave, null, 2));
      
      const response = await fetch('/api/configuracion', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(dataToSave)
      });

      console.log('Estado de respuesta:', response.status);
      console.log('Headers de respuesta:', Object.fromEntries(response.headers.entries()));

      if (response.ok) {
        const responseText = await response.text();
        console.log('Respuesta cruda:', responseText);
        
        let updatedConfig;
        try {
          updatedConfig = JSON.parse(responseText);
        } catch (parseError) {
          console.error('Error parsing response:', parseError);
          throw new Error('Respuesta inválida del servidor');
        }

        console.log('Configuración actualizada:', JSON.stringify(updatedConfig, null, 2));
        
        // Actualizar el estado local con los datos guardados
        setConfig(updatedConfig);
        
        toast({
          title: 'Éxito',
          description: 'Configuración guardada correctamente'
        });
      } else {
        let errorData;
        try {
          const errorText = await response.text();
          console.error('Error response text:', errorText);
          
          try {
            errorData = JSON.parse(errorText);
            console.error('Error response JSON:', errorData);
          } catch {
            errorData = { message: errorText };
          }
        } catch (textError) {
          console.error('Error reading error response:', textError);
          errorData = { message: 'Error desconocido del servidor' };
        }
        
        const errorMessage = errorData?.error || errorData?.message || `Error HTTP ${response.status}`;
        throw new Error(errorMessage);
      }
    } catch (error) {
      console.error('Error completo saving config:', error);
      console.error('Stack trace:', error instanceof Error ? error.stack : 'No stack available');
      
      let errorMessage = 'No se pudo guardar la configuración';
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      
      toast({
        title: 'Error al Guardar',
        description: errorMessage,
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-6 p-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Configuración de Empresa</h2>
          <p className="text-muted-foreground">
            Personaliza la información y apariencia de tu empresa
          </p>
        </div>

        <div className="grid gap-6">
          {/* Información Básica */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Información Básica
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nombreEmpresa">Nombre de la Empresa</Label>
                  <Input
                    id="nombreEmpresa"
                    value={config?.nombreEmpresa || ''}
                    onChange={(e) => handleInputChange('nombreEmpresa', e.target.value)}
                    placeholder="Mi Empresa de Transporte"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email Corporativo</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      className="pl-9"
                      value={config?.email || ''}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="contacto@empresa.com"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefono">Teléfono</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="telefono"
                      className="pl-9"
                      value={config?.telefono || ''}
                      onChange={(e) => handleInputChange('telefono', e.target.value)}
                      placeholder="+34 XXX XXX XXX"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="sitioWeb">Sitio Web</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="sitioWeb"
                      className="pl-9"
                      value={config?.sitioWeb || ''}
                      onChange={(e) => handleInputChange('sitioWeb', e.target.value)}
                      placeholder="https://www.empresa.com"
                    />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="direccion">Dirección</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Textarea
                    id="direccion"
                    className="pl-9"
                    value={config?.direccion || ''}
                    onChange={(e) => handleInputChange('direccion', e.target.value)}
                    placeholder="Calle Principal, 123, Ciudad, CP"
                    rows={2}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Logo */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ImageIcon className="h-5 w-5" />
                Logotipo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                {config?.logoUrl && (
                  <div className="relative w-20 h-20 border rounded-lg overflow-hidden">
                    <Image
                      src={config.logoUrl}
                      alt="Logo de empresa"
                      fill
                      style={{ objectFit: 'contain' }}
                      className="p-2"
                    />
                  </div>
                )}
                <div className="flex-1 space-y-2">
                  <Label htmlFor="logoFile">Subir nuevo logo</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="logoFile"
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      disabled={isUploading}
                      className="flex-1"
                    />
                    <Button
                      onClick={() => document.getElementById('logoFile')?.click()}
                      disabled={isUploading}
                      variant="outline"
                    >
                      {isUploading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Upload className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Formatos soportados: JPG, PNG, GIF. Máximo 5MB.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Colores */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="h-5 w-5" />
                Colores de Marca
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="colorPrimario">Color Primario</Label>
                  <div className="flex gap-2">
                    <Input
                      id="colorPrimario"
                      type="color"
                      value={config?.colorPrimario || '#3B82F6'}
                      onChange={(e) => handleInputChange('colorPrimario', e.target.value)}
                      className="w-16 h-10 p-1 border rounded"
                    />
                    <Input
                      value={config?.colorPrimario || '#3B82F6'}
                      onChange={(e) => handleInputChange('colorPrimario', e.target.value)}
                      placeholder="#3B82F6"
                      className="flex-1"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="colorSecundario">Color Secundario</Label>
                  <div className="flex gap-2">
                    <Input
                      id="colorSecundario"
                      type="color"
                      value={config?.colorSecundario || '#1E40AF'}
                      onChange={(e) => handleInputChange('colorSecundario', e.target.value)}
                      className="w-16 h-10 p-1 border rounded"
                    />
                    <Input
                      value={config?.colorSecundario || '#1E40AF'}
                      onChange={(e) => handleInputChange('colorSecundario', e.target.value)}
                      placeholder="#1E40AF"
                      className="flex-1"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Separator />

        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={isSaving} size="lg">
            {isSaving ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Guardar Configuración
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}
