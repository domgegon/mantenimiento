
'use client';

import { useState, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { useToast } from '@/hooks/use-toast';
import { Loader2, ChevronDown, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AddMaquinaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const marcas = ['Toyota', 'Jungheinrich', 'Still', 'Linde', 'Hyster', 'Crown', 'BT', 'Yale'];

interface MarcaComboBoxProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

function MarcaComboBox({ value, onChange, placeholder = "Seleccionar o escribir marca" }: MarcaComboBoxProps) {
  const [open, setOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  const filteredMarcas = marcas.filter(marca =>
    marca.toLowerCase().includes(searchValue.toLowerCase())
  );

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
        >
          {value || placeholder}
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0">
        <div className="p-2">
          <Input
            placeholder="Buscar o escribir nueva marca..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                onChange(searchValue);
                setOpen(false);
                setSearchValue('');
              }
            }}
          />
        </div>
        <div className="max-h-60 overflow-auto">
          {searchValue && !filteredMarcas.find(m => m.toLowerCase() === searchValue.toLowerCase()) && (
            <div
              className="flex cursor-pointer items-center px-3 py-2 text-sm hover:bg-accent"
              onClick={() => {
                onChange(searchValue);
                setOpen(false);
                setSearchValue('');
              }}
            >
              <div className="ml-2">
                Crear nueva marca: "{searchValue}"
              </div>
            </div>
          )}
          {filteredMarcas.map((marca) => (
            <div
              key={marca}
              className={cn(
                "flex cursor-pointer items-center px-3 py-2 text-sm hover:bg-accent",
                value === marca ? "bg-accent" : ""
              )}
              onClick={() => {
                onChange(marca);
                setOpen(false);
                setSearchValue('');
              }}
            >
              <Check
                className={cn(
                  "mr-2 h-4 w-4",
                  value === marca ? "opacity-100" : "opacity-0"
                )}
              />
              {marca}
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}

export function AddMaquinaModal({ isOpen, onClose, onSuccess }: AddMaquinaModalProps) {
  const [formData, setFormData] = useState({
    numeroSerie: '',
    marca: '',
    modelo: '',
    empresaAlquila: '',
    costeAlquiler: '',
    ubicacion: '',
    contrato: '',
    fechaRenovacion: ''
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/inventario', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...formData,
          costeAlquiler: parseFloat(formData.costeAlquiler) || 0,
          fechaRenovacion: formData.fechaRenovacion ? new Date(formData.fechaRenovacion).toISOString() : null,
        }),
      });

      if (response.ok) {
        toast({
          title: "Éxito",
          description: "Máquina agregada correctamente",
        });
        setFormData({
          numeroSerie: '',
          marca: '',
          modelo: '',
          empresaAlquila: '',
          costeAlquiler: '',
          ubicacion: '',
          contrato: '',
          fechaRenovacion: ''
        });
        onSuccess();
        onClose();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error al agregar la máquina');
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al agregar la máquina",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Agregar Nueva Máquina</DialogTitle>
          <DialogDescription>
            Complete los datos de la nueva máquina para agregarla al inventario.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="numeroSerie">Número de Serie*</Label>
                <Input
                  id="numeroSerie"
                  value={formData.numeroSerie}
                  onChange={(e) => handleInputChange('numeroSerie', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="marca">Marca*</Label>
                <MarcaComboBox
                  value={formData.marca}
                  onChange={(value) => handleInputChange('marca', value)}
                  placeholder="Seleccionar o escribir marca"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="modelo">Modelo*</Label>
                <Input
                  id="modelo"
                  value={formData.modelo}
                  onChange={(e) => handleInputChange('modelo', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="costeAlquiler">Coste Alquiler (€/mes) - Puede ser 0</Label>
                <Input
                  id="costeAlquiler"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.costeAlquiler}
                  onChange={(e) => handleInputChange('costeAlquiler', e.target.value)}
                  placeholder="0.00"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="empresaAlquila">Empresa que Alquila*</Label>
              <Input
                id="empresaAlquila"
                value={formData.empresaAlquila}
                onChange={(e) => handleInputChange('empresaAlquila', e.target.value)}
                placeholder="Ej: Linde Material Handling"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ubicacion">Ubicación*</Label>
              <Input
                id="ubicacion"
                value={formData.ubicacion}
                onChange={(e) => handleInputChange('ubicacion', e.target.value)}
                placeholder="Ej: Madrid - Coslada"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contrato">Número de Contrato</Label>
                <Input
                  id="contrato"
                  value={formData.contrato}
                  onChange={(e) => handleInputChange('contrato', e.target.value)}
                  placeholder="Ej: CT-2024-001"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="fechaRenovacion">Fecha de Renovación</Label>
                <Input
                  id="fechaRenovacion"
                  type="date"
                  value={formData.fechaRenovacion}
                  onChange={(e) => handleInputChange('fechaRenovacion', e.target.value)}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Agregar Máquina
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
