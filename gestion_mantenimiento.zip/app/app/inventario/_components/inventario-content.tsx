
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Package, 
  Search, 
  Plus, 
  Edit, 
  Trash2,
  Filter,
  Download,
  MapPin,
  DollarSign,
  Calendar,
  Truck
} from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { AddMaquinaModal } from './add-maquina-modal';
import { EditMaquinaModal } from './edit-maquina-modal';

interface Maquina {
  id: string;
  numeroSerie: string;
  marca: string;
  modelo: string;
  empresaAlquila: string;
  costeAlquiler: number;
  ubicacion: string;
  contrato: string | null;
  fechaRenovacion: string | null;
  fechaCreacion: string;
  _count?: {
    averias: number;
  };
}

const marcas = ['Todas', 'Toyota', 'Jungheinrich', 'Still', 'Linde', 'Hyster', 'Crown', 'BT', 'Yale'];
const ubicaciones = ['Todas', 'Madrid - Coslada', 'Barcelona - Mercabarna', 'Valencia - Puerto', 'Sevilla - Centro', 'Zaragoza - Plaza', 'Bilbao - Zona Franca', 'Málaga - Guadalhorce', 'Murcia - Espinardo'];

export function InventarioContent() {
  const [maquinas, setMaquinas] = useState<Maquina[]>([]);
  const [filteredMaquinas, setFilteredMaquinas] = useState<Maquina[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [marcaFilter, setMarcaFilter] = useState('Todas');
  const [ubicacionFilter, setUbicacionFilter] = useState('Todas');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingMaquinaId, setEditingMaquinaId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchMaquinas();
  }, []);

  useEffect(() => {
    let filtered = maquinas;

    if (searchTerm) {
      filtered = filtered?.filter?.(maquina =>
        maquina?.numeroSerie?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.()) ||
        maquina?.marca?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.()) ||
        maquina?.modelo?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.()) ||
        maquina?.empresaAlquila?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.())
      ) || [];
    }

    if (marcaFilter && marcaFilter !== 'Todas') {
      filtered = filtered?.filter?.(maquina => maquina?.marca === marcaFilter) || [];
    }

    if (ubicacionFilter && ubicacionFilter !== 'Todas') {
      filtered = filtered?.filter?.(maquina => maquina?.ubicacion === ubicacionFilter) || [];
    }

    setFilteredMaquinas(filtered);
  }, [maquinas, searchTerm, marcaFilter, ubicacionFilter]);

  const fetchMaquinas = async () => {
    try {
      const response = await fetch('/api/inventario');
      if (response?.ok) {
        const data = await response?.json?.();
        setMaquinas(data?.maquinas || []);
      }
    } catch (error) {
      console.error('Error fetching maquinas:', error);
      toast({
        title: "Error",
        description: "Error al cargar el inventario",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar esta máquina?')) return;

    try {
      const response = await fetch(`/api/inventario/${id}`, {
        method: 'DELETE'
      });

      if (response?.ok) {
        toast({
          title: "Éxito",
          description: "Máquina eliminada correctamente",
        });
        fetchMaquinas();
      }
    } catch (error) {
      console.error('Error deleting maquina:', error);
      toast({
        title: "Error",
        description: "Error al eliminar la máquina",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (id: string) => {
    setEditingMaquinaId(id);
    setShowEditModal(true);
  };

  const handleModalSuccess = () => {
    fetchMaquinas();
  };

  const exportToCSV = () => {
    const headers = ['Número Serie', 'Marca', 'Modelo', 'Empresa Alquila', 'Coste Alquiler', 'Ubicación', 'Contrato', 'Fecha Renovación', 'Averías'];
    const csvContent = [
      headers.join(','),
      ...filteredMaquinas?.map?.(m => [
        m?.numeroSerie || '',
        m?.marca || '',
        m?.modelo || '',
        m?.empresaAlquila || '',
        m?.costeAlquiler || 0,
        m?.ubicacion || '',
        m?.contrato || '',
        m?.fechaRenovacion ? new Date(m.fechaRenovacion).toLocaleDateString('es-ES') : '',
        m?._count?.averias || 0
      ]?.join?.(',')) || []
    ]?.join?.('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window?.URL?.createObjectURL?.(blob);
    const a = document?.createElement?.('a');
    a.href = url;
    a.download = 'inventario.csv';
    a.click();
    window?.URL?.revokeObjectURL?.(url);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b pb-6"
      >
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
              <Package className="w-8 h-8 text-blue-600" />
              Gestión de Inventario
            </h1>
            <p className="text-gray-600">Administración de máquinas y equipos</p>
          </div>
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={() => setShowAddModal(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Agregar Máquina
          </Button>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Package className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Máquinas</p>
                <p className="text-2xl font-bold">{maquinas?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Coste Mensual</p>
                <p className="text-2xl font-bold">
                  €{maquinas?.reduce?.((sum, m) => sum + (Number(m?.costeAlquiler) || 0), 0)?.toLocaleString?.('es-ES') || '0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <MapPin className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Centros Activos</p>
                <p className="text-2xl font-bold">
                  {new Set(maquinas?.map?.(m => m?.ubicacion)?.filter?.(Boolean))?.size || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Truck className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Marcas</p>
                <p className="text-2xl font-bold">
                  {new Set(maquinas?.map?.(m => m?.marca)?.filter?.(Boolean))?.size || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtros y Búsqueda
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por número de serie, marca..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e?.target?.value || '')}
                className="pl-10"
              />
            </div>

            <Select value={marcaFilter} onValueChange={setMarcaFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar marca" />
              </SelectTrigger>
              <SelectContent>
                {marcas?.map?.(marca => (
                  <SelectItem key={marca} value={marca || 'todas'}>
                    {marca}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={ubicacionFilter} onValueChange={setUbicacionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar ubicación" />
              </SelectTrigger>
              <SelectContent>
                {ubicaciones?.map?.(ubicacion => (
                  <SelectItem key={ubicacion} value={ubicacion || 'todas'}>
                    {ubicacion}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={exportToCSV}>
              <Download className="w-4 h-4 mr-2" />
              Exportar CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>
            Inventario de Máquinas ({filteredMaquinas?.length || 0})
          </CardTitle>
          <CardDescription>
            Lista completa del inventario con detalles de cada máquina
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Número Serie</TableHead>
                  <TableHead>Marca</TableHead>
                  <TableHead>Modelo</TableHead>
                  <TableHead>Empresa Alquila</TableHead>
                  <TableHead>Coste Mensual</TableHead>
                  <TableHead>Ubicación</TableHead>
                  <TableHead>Contrato</TableHead>
                  <TableHead>Renovación</TableHead>
                  <TableHead>Averías</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMaquinas?.length ? filteredMaquinas?.map?.((maquina) => (
                  <TableRow key={maquina?.id}>
                    <TableCell className="font-medium">
                      {maquina?.numeroSerie}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{maquina?.marca}</Badge>
                    </TableCell>
                    <TableCell>{maquina?.modelo}</TableCell>
                    <TableCell className="text-sm">{maquina?.empresaAlquila}</TableCell>
                    <TableCell className="font-semibold text-green-600">
                      €{Number(maquina?.costeAlquiler)?.toLocaleString?.('es-ES') || '0'}/mes
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span className="text-sm">{maquina?.ubicacion}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {maquina?.contrato || '-'}
                    </TableCell>
                    <TableCell className="text-sm">
                      {maquina?.fechaRenovacion ? 
                        new Date(maquina.fechaRenovacion).toLocaleDateString('es-ES') : 
                        '-'
                      }
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={maquina?._count?.averias && maquina._count.averias > 0 ? "destructive" : "default"}
                      >
                        {maquina?._count?.averias || 0}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleEdit(maquina?.id)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleDelete(maquina?.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8 text-gray-500">
                      No se encontraron máquinas con los filtros seleccionados
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modales */}
      <AddMaquinaModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={handleModalSuccess}
      />
      
      <EditMaquinaModal
        isOpen={showEditModal}
        onClose={() => {
          setShowEditModal(false);
          setEditingMaquinaId(null);
        }}
        onSuccess={handleModalSuccess}
        maquinaId={editingMaquinaId}
      />
    </div>
  );
}
