
import { MainLayout } from '@/components/main-layout';
import { InventarioContent } from './_components/inventario-content';

export const dynamic = 'force-dynamic';

export default function InventarioPage() {
  return (
    <MainLayout>
      <InventarioContent />
    </MainLayout>
  );
}
