
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Wrench, 
  Search, 
  Plus, 
  Edit, 
  Trash2,
  Filter,
  Download,
  Calendar,
  DollarSign,
  AlertTriangle,
  Clock
} from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { AddAveriaModal } from './add-averia-modal';
import { EditAveriaModal } from './edit-averia-modal';

interface Averia {
  id: string;
  fecha: string;
  tipoAveria: string;
  coste: number;
  descripcion: string;
  maquina: {
    numeroSerie: string;
    marca: string;
    modelo: string;
    ubicacion: string;
  };
}

const tiposAveria = [
  'Todas',
  'Fallo motor',
  'Sistema hidráulico',
  'Frenos desgastados',
  'Batería agotada',
  'Cadenas elevación',
  'Ruedas desgaste',
  'Sistema eléctrico',
  'Mástil elevador',
  'Transmisión',
  'Dirección asistida',
  'Válvulas hidráulicas'
];

const ubicaciones = ['Todas', 'Madrid - Coslada', 'Barcelona - Mercabarna', 'Valencia - Puerto', 'Sevilla - Centro', 'Zaragoza - Plaza', 'Bilbao - Zona Franca', 'Málaga - Guadalhorce', 'Murcia - Espinardo'];

export function AveriasContent() {
  const [averias, setAverias] = useState<Averia[]>([]);
  const [filteredAverias, setFilteredAverias] = useState<Averia[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [tipoFilter, setTipoFilter] = useState('Todas');
  const [ubicacionFilter, setUbicacionFilter] = useState('Todas');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingAveriaId, setEditingAveriaId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchAverias();
  }, []);

  useEffect(() => {
    let filtered = averias;

    if (searchTerm) {
      filtered = filtered?.filter?.(averia =>
        averia?.maquina?.numeroSerie?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.()) ||
        averia?.tipoAveria?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.()) ||
        averia?.descripcion?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.()) ||
        averia?.maquina?.marca?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.())
      ) || [];
    }

    if (tipoFilter && tipoFilter !== 'Todas') {
      filtered = filtered?.filter?.(averia => averia?.tipoAveria === tipoFilter) || [];
    }

    if (ubicacionFilter && ubicacionFilter !== 'Todas') {
      filtered = filtered?.filter?.(averia => averia?.maquina?.ubicacion === ubicacionFilter) || [];
    }

    setFilteredAverias(filtered);
  }, [averias, searchTerm, tipoFilter, ubicacionFilter]);

  const fetchAverias = async () => {
    try {
      const response = await fetch('/api/averias');
      if (response?.ok) {
        const data = await response?.json?.();
        setAverias(data?.averias || []);
      }
    } catch (error) {
      console.error('Error fetching averias:', error);
      toast({
        title: "Error",
        description: "Error al cargar las averías",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('¿Está seguro de eliminar esta avería?')) return;

    try {
      const response = await fetch(`/api/averias/${id}`, {
        method: 'DELETE'
      });

      if (response?.ok) {
        toast({
          title: "Éxito",
          description: "Avería eliminada correctamente",
        });
        fetchAverias();
      }
    } catch (error) {
      console.error('Error deleting averia:', error);
      toast({
        title: "Error",
        description: "Error al eliminar la avería",
        variant: "destructive",
      });
    }
  };

  const handleEdit = (id: string) => {
    setEditingAveriaId(id);
    setShowEditModal(true);
  };

  const handleModalSuccess = () => {
    fetchAverias();
  };

  const exportToCSV = () => {
    const headers = ['Fecha', 'Número Serie', 'Marca', 'Tipo Avería', 'Coste', 'Ubicación', 'Descripción'];
    const csvContent = [
      headers.join(','),
      ...filteredAverias?.map?.(a => [
        a?.fecha ? format(new Date(a.fecha), 'dd/MM/yyyy', { locale: es }) : '',
        a?.maquina?.numeroSerie || '',
        a?.maquina?.marca || '',
        a?.tipoAveria || '',
        a?.coste || 0,
        a?.maquina?.ubicacion || '',
        `"${a?.descripcion?.replace?.(/"/g, '""') || ''}"` // Escapar comillas en descripción
      ]?.join?.(',')) || []
    ]?.join?.('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window?.URL?.createObjectURL?.(blob);
    const a = document?.createElement?.('a');
    a.href = url;
    a.download = 'averias.csv';
    a.click();
    window?.URL?.revokeObjectURL?.(url);
  };

  const totalCosteAverias = filteredAverias?.reduce?.((sum, averia) => sum + (Number(averia?.coste) || 0), 0) || 0;
  const promedioCoste = filteredAverias?.length ? totalCosteAverias / filteredAverias.length : 0;

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b pb-6"
      >
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
              <Wrench className="w-8 h-8 text-orange-600" />
              Gestión de Averías
            </h1>
            <p className="text-gray-600">Registro y seguimiento de reparaciones</p>
          </div>
          <Button 
            className="bg-orange-600 hover:bg-orange-700"
            onClick={() => setShowAddModal(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Registrar Avería
          </Button>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Wrench className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Averías</p>
                <p className="text-2xl font-bold">{filteredAverias?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <DollarSign className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Coste Total</p>
                <p className="text-2xl font-bold">
                  €{totalCosteAverias?.toLocaleString?.('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) || '0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Coste Promedio</p>
                <p className="text-2xl font-bold">
                  €{promedioCoste?.toLocaleString?.('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) || '0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Clock className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Este Mes</p>
                <p className="text-2xl font-bold">
                  {filteredAverias?.filter?.(a => {
                    const fecha = new Date(a?.fecha || '');
                    const ahora = new Date();
                    return fecha?.getMonth?.() === ahora?.getMonth?.() && 
                           fecha?.getFullYear?.() === ahora?.getFullYear?.();
                  })?.length || 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtros y Búsqueda
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por número de serie, tipo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e?.target?.value || '')}
                className="pl-10"
              />
            </div>

            <Select value={tipoFilter} onValueChange={setTipoFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo de avería" />
              </SelectTrigger>
              <SelectContent>
                {tiposAveria?.map?.(tipo => (
                  <SelectItem key={tipo} value={tipo || 'todas'}>
                    {tipo}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={ubicacionFilter} onValueChange={setUbicacionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Seleccionar ubicación" />
              </SelectTrigger>
              <SelectContent>
                {ubicaciones?.map?.(ubicacion => (
                  <SelectItem key={ubicacion} value={ubicacion || 'todas'}>
                    {ubicacion}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={exportToCSV}>
              <Download className="w-4 h-4 mr-2" />
              Exportar CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>
            Registro de Averías ({filteredAverias?.length || 0})
          </CardTitle>
          <CardDescription>
            Historial completo de averías y reparaciones
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Número Serie</TableHead>
                  <TableHead>Marca</TableHead>
                  <TableHead>Tipo de Avería</TableHead>
                  <TableHead>Coste</TableHead>
                  <TableHead>Ubicación</TableHead>
                  <TableHead>Descripción</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAverias?.length ? filteredAverias?.map?.((averia) => (
                  <TableRow key={averia?.id}>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-gray-400" />
                        <span className="text-sm">
                          {averia?.fecha ? format(new Date(averia.fecha), 'dd/MM/yyyy', { locale: es }) : 'N/A'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">
                      {averia?.maquina?.numeroSerie}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{averia?.maquina?.marca}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={
                          averia?.tipoAveria?.includes?.('motor') || averia?.tipoAveria?.includes?.('transmisión') 
                            ? "destructive" 
                            : "default"
                        }
                      >
                        {averia?.tipoAveria}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-semibold text-red-600">
                      €{Number(averia?.coste)?.toLocaleString?.('es-ES') || '0'}
                    </TableCell>
                    <TableCell className="text-sm">
                      {averia?.maquina?.ubicacion}
                    </TableCell>
                    <TableCell className="max-w-xs">
                      <p className="text-sm text-gray-600 truncate" title={averia?.descripcion}>
                        {averia?.descripcion}
                      </p>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleEdit(averia?.id)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => handleDelete(averia?.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                      No se encontraron averías con los filtros seleccionados
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modales */}
      <AddAveriaModal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSuccess={handleModalSuccess}
      />
      
      <EditAveriaModal
        isOpen={showEditModal}
        onClose={() => {
          setShowEditModal(false);
          setEditingAveriaId(null);
        }}
        onSuccess={handleModalSuccess}
        averiaId={editingAveriaId}
      />
    </div>
  );
}
