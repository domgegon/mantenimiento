
'use client';

import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { format } from 'date-fns';

interface AddAveriaModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface Maquina {
  id: string;
  numeroSerie: string;
  marca: string;
  modelo: string;
}

const tiposAveria = [
  'Fallo motor',
  'Sistema hidráulico',
  'Frenos desgastados',
  'Batería agotada',
  'Cadenas elevación',
  'Ruedas desgaste',
  'Sistema eléctrico',
  'Mástil elevador',
  'Transmisión',
  'Dirección asistida',
  'Válvulas hidráulicas'
];

export function AddAveriaModal({ isOpen, onClose, onSuccess }: AddAveriaModalProps) {
  const [formData, setFormData] = useState({
    maquinaId: '',
    fecha: format(new Date(), 'yyyy-MM-dd'),
    tipoAveria: '',
    coste: '',
    descripcion: ''
  });
  const [maquinas, setMaquinas] = useState<Maquina[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMaquinas, setLoadingMaquinas] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      fetchMaquinas();
    }
  }, [isOpen]);

  const fetchMaquinas = async () => {
    setLoadingMaquinas(true);
    try {
      const response = await fetch('/api/inventario');
      if (response.ok) {
        const data = await response.json();
        setMaquinas(data.maquinas || []);
      }
    } catch (error) {
      console.error('Error fetching maquinas:', error);
      toast({
        title: "Error",
        description: "Error al cargar las máquinas",
        variant: "destructive",
      });
    } finally {
      setLoadingMaquinas(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/averias', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          maquinaId: formData.maquinaId,
          fecha: new Date(formData.fecha).toISOString(),
          tipoAveria: formData.tipoAveria,
          coste: parseFloat(formData.coste) || 0,
          descripcion: formData.descripcion
        }),
      });

      if (response.ok) {
        toast({
          title: "Éxito",
          description: "Avería registrada correctamente",
        });
        setFormData({
          maquinaId: '',
          fecha: format(new Date(), 'yyyy-MM-dd'),
          tipoAveria: '',
          coste: '',
          descripcion: ''
        });
        onSuccess();
        onClose();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error al registrar la avería');
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Error al registrar la avería",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Registrar Nueva Avería</DialogTitle>
          <DialogDescription>
            Complete los datos de la avería para registrarla en el sistema.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="maquinaId">Máquina*</Label>
              <Select 
                value={formData.maquinaId} 
                onValueChange={(value) => handleInputChange('maquinaId', value)}
                disabled={loadingMaquinas}
              >
                <SelectTrigger>
                  <SelectValue placeholder={loadingMaquinas ? "Cargando máquinas..." : "Seleccionar máquina"} />
                </SelectTrigger>
                <SelectContent>
                  {maquinas.map(maquina => (
                    <SelectItem key={maquina.id} value={maquina.id}>
                      {maquina.numeroSerie} - {maquina.marca} {maquina.modelo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fecha">Fecha*</Label>
                <Input
                  id="fecha"
                  type="date"
                  value={formData.fecha}
                  onChange={(e) => handleInputChange('fecha', e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="coste">Coste (€)*</Label>
                <Input
                  id="coste"
                  type="number"
                  step="0.01"
                  value={formData.coste}
                  onChange={(e) => handleInputChange('coste', e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipoAveria">Tipo de Avería*</Label>
              <Input
                id="tipoAveria"
                value={formData.tipoAveria}
                onChange={(e) => handleInputChange('tipoAveria', e.target.value)}
                placeholder="Ej: Fallo motor, Sistema hidráulico..."
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                value={formData.descripcion}
                onChange={(e) => handleInputChange('descripcion', e.target.value)}
                placeholder="Descripción detallada de la avería..."
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading || loadingMaquinas}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Registrar Avería
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
