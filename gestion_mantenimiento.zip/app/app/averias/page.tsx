
import { MainLayout } from '@/components/main-layout';
import { AveriasContent } from './_components/averias-content';

export const dynamic = 'force-dynamic';

export default function AveriasPage() {
  return (
    <MainLayout>
      <AveriasContent />
    </MainLayout>
  );
}
