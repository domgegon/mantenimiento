
import { MainLayout } from '@/components/main-layout';
import { AnalisisContent } from './_components/analisis-content';

export const dynamic = 'force-dynamic';

export default function AnalisisPage() {
  return (
    <MainLayout>
      <AnalisisContent />
    </MainLayout>
  );
}
