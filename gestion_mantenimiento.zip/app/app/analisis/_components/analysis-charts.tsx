
'use client';

import { 
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  AreaChart,
  Area,
  ScatterChart,
  Scatter
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { 
  BarChart3,
  Target
} from 'lucide-react';

interface TendenciasData {
  costeMensual: Array<{ mes: string; coste: number; cantidad: number }>;
  eficienciaPorCentro: Array<{ centro: string; disponibilidad: number; coste: number }>;
}

interface ChartsProps {
  tendencias: TendenciasData;
}

export default function AnalysisCharts({ tendencias }: ChartsProps) {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Evolución Mensual de Costes */}
      <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.5 }}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              Evolución Mensual de Costes
            </CardTitle>
            <CardDescription>
              Análisis de costes y cantidad de averías por mes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={tendencias.costeMensual} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <defs>
                    <linearGradient id="colorCoste" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#60B5FF" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#60B5FF" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="mes"
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    label={{ 
                      value: 'Coste (€)', 
                      angle: -90, 
                      position: 'insideLeft',
                      style: { textAnchor: 'middle', fontSize: 11 }
                    }}
                  />
                  <Tooltip 
                    formatter={(value: any) => [`€${Number(value)?.toLocaleString('es-ES')}`, 'Coste']}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="coste" 
                    stroke="#60B5FF" 
                    fillOpacity={1} 
                    fill="url(#colorCoste)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Eficiencia por Centro */}
      <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.6 }}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-green-600" />
              Eficiencia por Centro
            </CardTitle>
            <CardDescription>
              Disponibilidad vs Coste de mantenimiento
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart data={tendencias.eficienciaPorCentro} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <XAxis 
                    dataKey="disponibilidad"
                    type="number"
                    domain={['dataMin - 5', 'dataMax + 5']}
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    label={{ 
                      value: 'Disponibilidad (%)', 
                      position: 'insideBottom',
                      offset: -15,
                      style: { textAnchor: 'middle', fontSize: 11 }
                    }}
                  />
                  <YAxis 
                    dataKey="coste"
                    type="number"
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    label={{ 
                      value: 'Coste (€)', 
                      angle: -90, 
                      position: 'insideLeft',
                      style: { textAnchor: 'middle', fontSize: 11 }
                    }}
                  />
                  <Tooltip 
                    formatter={(value: any, name: string) => [
                      name === 'disponibilidad' ? `${Number(value)}%` : `€${Number(value)?.toLocaleString('es-ES')}`,
                      name === 'disponibilidad' ? 'Disponibilidad' : 'Coste'
                    ]}
                    labelFormatter={(label: string) => `Centro: ${label}`}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                  <Scatter dataKey="coste" fill="#72BF78" />
                </ScatterChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
