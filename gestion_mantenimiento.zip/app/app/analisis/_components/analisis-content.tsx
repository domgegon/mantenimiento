
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  BarChart3,
  AlertTriangle,
  Target,
  Zap,
  Clock,
  DollarSign,
  Package
} from 'lucide-react';
import { motion } from 'framer-motion';
import dynamic from 'next/dynamic';

// Componente dinámico para gráficos
const AnalysisCharts = dynamic(() => import('./analysis-charts'), { 
  ssr: false,
  loading: () => <div className="h-80 animate-pulse bg-gray-200 rounded"></div>
});

interface AnalysisData {
  eficiencia: {
    disponibilidad: number;
    tiempoPromedioReparacion: number;
    costePorMaquina: number;
    frecuenciaAverias: number;
  };
  tendencias: {
    costeMensual: Array<{ mes: string; coste: number; cantidad: number }>;
    eficienciaPorCentro: Array<{ centro: string; disponibilidad: number; coste: number }>;
    correlacionEdadAverias: Array<{ edad: number; averias: number; coste: number }>;
    prediccionCostes: Array<{ mes: string; real: number; prediccion: number }>;
  };
  rankings: {
    centrosMasCostosos: Array<{ nombre: string; coste: number; averias: number }>;
    maquinasProblematicas: Array<{ numeroSerie: string; marca: string; averias: number; coste: number }>;
    tiposAveriasCriticas: Array<{ tipo: string; frecuencia: number; costePromedio: number }>;
  };
}

export function AnalisisContent() {
  const [data, setData] = useState<AnalysisData>({
    eficiencia: {
      disponibilidad: 0,
      tiempoPromedioReparacion: 0,
      costePorMaquina: 0,
      frecuenciaAverias: 0
    },
    tendencias: {
      costeMensual: [],
      eficienciaPorCentro: [],
      correlacionEdadAverias: [],
      prediccionCostes: []
    },
    rankings: {
      centrosMasCostosos: [],
      maquinasProblematicas: [],
      tiposAveriasCriticas: []
    }
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalysisData();
  }, []);

  const fetchAnalysisData = async () => {
    try {
      const response = await fetch('/api/analisis');
      if (response?.ok) {
        const analysisData = await response?.json?.();
        setData(analysisData);
      }
    } catch (error) {
      console.error('Error fetching analysis data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="p-8 space-y-8 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b pb-6"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
          <TrendingUp className="w-8 h-8 text-purple-600" />
          Análisis Avanzado
        </h1>
        <p className="text-gray-600">Análisis detallado de rendimiento y tendencias</p>
      </motion.div>

      {/* KPIs Principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Disponibilidad</CardTitle>
              <Target className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{data?.eficiencia?.disponibilidad?.toFixed?.(1) || 0}%</div>
              <p className="text-xs opacity-80 mt-1">Máquinas operativas</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.2 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Tiempo Reparación</CardTitle>
              <Clock className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{data?.eficiencia?.tiempoPromedioReparacion?.toFixed?.(1) || 0}</div>
              <p className="text-xs opacity-80 mt-1">Días promedio</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.3 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Coste por Máquina</CardTitle>
              <DollarSign className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">€{data?.eficiencia?.costePorMaquina?.toLocaleString?.('es-ES', { maximumFractionDigits: 0 }) || '0'}</div>
              <p className="text-xs opacity-80 mt-1">Promedio anual</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.4 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Frecuencia Averías</CardTitle>
              <Zap className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{data?.eficiencia?.frecuenciaAverias?.toFixed?.(1) || 0}</div>
              <p className="text-xs opacity-80 mt-1">Averías por máquina/año</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Gráficos de Tendencias */}
      <AnalysisCharts tendencias={data.tendencias} />

      {/* Rankings y Análisis Detallado */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Centros Más Costosos */}
        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.7 }}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Centros Más Costosos
              </CardTitle>
              <CardDescription>
                Ranking por coste de mantenimiento
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {data?.rankings?.centrosMasCostosos?.slice?.(0, 5)?.map?.((centro, index) => (
                <div key={centro?.nombre} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold text-white ${
                      index === 0 ? 'bg-red-500' : index === 1 ? 'bg-orange-500' : index === 2 ? 'bg-yellow-500' : 'bg-gray-400'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{centro?.nombre}</p>
                      <p className="text-xs text-gray-500">{centro?.averias} averías</p>
                    </div>
                  </div>
                  <Badge variant="destructive">
                    €{centro?.coste?.toLocaleString?.('es-ES', { maximumFractionDigits: 0 }) || '0'}
                  </Badge>
                </div>
              )) || []}
            </CardContent>
          </Card>
        </motion.div>

        {/* Máquinas Problemáticas */}
        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.8 }}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5 text-orange-600" />
                Máquinas Problemáticas
              </CardTitle>
              <CardDescription>
                Equipos con más averías
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {data?.rankings?.maquinasProblematicas?.slice?.(0, 5)?.map?.((maquina, index) => (
                <div key={maquina?.numeroSerie} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold text-white ${
                      index === 0 ? 'bg-red-500' : index === 1 ? 'bg-orange-500' : index === 2 ? 'bg-yellow-500' : 'bg-gray-400'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{maquina?.numeroSerie}</p>
                      <p className="text-xs text-gray-500">{maquina?.marca}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="destructive">{maquina?.averias}</Badge>
                    <p className="text-xs text-gray-500 mt-1">
                      €{maquina?.coste?.toLocaleString?.('es-ES', { maximumFractionDigits: 0 }) || '0'}
                    </p>
                  </div>
                </div>
              )) || []}
            </CardContent>
          </Card>
        </motion.div>

        {/* Tipos de Averías Críticas */}
        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.9 }}>
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-600" />
                Averías Críticas
              </CardTitle>
              <CardDescription>
                Tipos más frecuentes y costosos
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {data?.rankings?.tiposAveriasCriticas?.slice?.(0, 5)?.map?.((tipo, index) => (
                <div key={tipo?.tipo} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold text-white ${
                      index === 0 ? 'bg-red-500' : index === 1 ? 'bg-orange-500' : index === 2 ? 'bg-yellow-500' : 'bg-gray-400'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{tipo?.tipo}</p>
                      <p className="text-xs text-gray-500">{tipo?.frecuencia} casos</p>
                    </div>
                  </div>
                  <Badge variant="default">
                    €{tipo?.costePromedio?.toLocaleString?.('es-ES', { maximumFractionDigits: 0 }) || '0'}
                  </Badge>
                </div>
              )) || []}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
