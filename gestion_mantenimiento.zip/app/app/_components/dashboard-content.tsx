
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Package, 
  Wrench, 
  TrendingUp, 
  DollarSign,
  AlertTriangle,
  MapPin,
  Calendar,
  Activity
} from 'lucide-react';
import { motion } from 'framer-motion';
import dynamic from 'next/dynamic';

// Componente dinámico para gráficos
const DashboardCharts = dynamic(() => import('./dashboard-charts'), { 
  ssr: false,
  loading: () => <div className="h-80 animate-pulse bg-gray-200 rounded"></div>
});

interface DashboardStats {
  totalMaquinas: number;
  totalAverias: number;
  costeTotal: number;
  costetMensual: number;
  averiasUltimos30Dias: number;
  maquinasConAverias: number;
}

interface ChartData {
  name: string;
  value: number;
  color?: string;
}

export function DashboardContent() {
  const [stats, setStats] = useState<DashboardStats>({
    totalMaquinas: 0,
    totalAverias: 0,
    costeTotal: 0,
    costetMensual: 0,
    averiasUltimos30Dias: 0,
    maquinasConAverias: 0
  });
  
  const [chartData, setChartData] = useState({
    costePorCentro: [] as ChartData[],
    tendenciaAverias: [] as ChartData[],
    tipoAverias: [] as ChartData[],
    marcasMasAverias: [] as ChartData[]
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const response = await fetch('/api/dashboard');
        const data = await response.json();
        setStats(data.stats);
        setChartData(data.charts);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="p-8 space-y-8 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b pb-6"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard de Gestión Logística</h1>
        <p className="text-gray-600">Panel de control del sistema de inventario y averías</p>
        <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
          <Calendar className="w-4 h-4" />
          <span>Última actualización: {new Date().toLocaleDateString('es-ES')}</span>
          <Activity className="w-4 h-4 ml-4" />
          <span className="text-green-600">Sistema operativo</span>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Total Máquinas</CardTitle>
              <Package className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalMaquinas}</div>
              <p className="text-xs opacity-80 mt-1">Inventario activo</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.2 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Total Averías</CardTitle>
              <Wrench className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats.totalAverias}</div>
              <p className="text-xs opacity-80 mt-1">
                +{stats.averiasUltimos30Dias} últimos 30 días
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.3 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-red-500 to-red-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Coste Total</CardTitle>
              <DollarSign className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">€{stats.costeTotal?.toLocaleString('es-ES', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) || '0'}</div>
              <p className="text-xs opacity-80 mt-1">En reparaciones</p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.4 }}>
          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium opacity-90">Disponibilidad</CardTitle>
              <TrendingUp className="h-5 w-5 opacity-80" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {stats.totalMaquinas > 0 ? Math.round((1 - stats.maquinasConAverias / stats.totalMaquinas) * 100) : 100}%
              </div>
              <p className="text-xs opacity-80 mt-1">Máquinas operativas</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts Grid */}
      <DashboardCharts chartData={chartData} />
    </div>
  );
}
