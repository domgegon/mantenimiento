
'use client';

import { 
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { 
  MapPin,
  AlertTriangle,
  TrendingUp,
  Activity
} from 'lucide-react';

interface ChartData {
  name: string;
  value: number;
}

interface ChartsProps {
  chartData: {
    costePorCentro: ChartData[];
    tendenciaAverias: ChartData[];
    tipoAverias: ChartData[];
    marcasMasAverias: ChartData[];
  };
}

const COLORS = ['#60B5FF', '#FF9149', '#FF9898', '#80D8C3', '#A19AD3', '#72BF78'];

export default function DashboardCharts({ chartData }: ChartsProps) {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Coste por Centro */}
      <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.5 }}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              Coste de Averías por Centro
            </CardTitle>
            <CardDescription>
              Distribución de costes de mantenimiento por ubicación
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData.costePorCentro} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 10 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    label={{ 
                      value: 'Coste (€)', 
                      angle: -90, 
                      position: 'insideLeft',
                      style: { textAnchor: 'middle', fontSize: 11 }
                    }}
                  />
                  <Tooltip 
                    formatter={(value: any) => [`€${Number(value)?.toLocaleString('es-ES')}`, 'Coste']}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                  <Bar dataKey="value" fill="#60B5FF" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Tipos de Averías */}
      <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.6 }}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              Tipos de Averías Más Comunes
            </CardTitle>
            <CardDescription>
              Distribución por tipo de fallo registrado
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData.tipoAverias}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={(entry) => entry.name}
                  >
                    {chartData.tipoAverias?.map?.((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: any) => [Number(value), 'Cantidad']}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                  <Legend 
                    verticalAlign="top"
                    height={36}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Marcas con Más Averías */}
      <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.7 }}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-red-600" />
              Marcas con Más Averías
            </CardTitle>
            <CardDescription>
              Ranking de marcas por número de incidencias
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData.marcasMasAverias} layout="horizontal" margin={{ top: 20, right: 30, left: 60, bottom: 20 }}>
                  <XAxis 
                    type="number"
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                  />
                  <YAxis 
                    type="category"
                    dataKey="name"
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    width={50}
                  />
                  <Tooltip 
                    formatter={(value: any) => [Number(value), 'Averías']}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                  <Bar dataKey="value" fill="#FF9149" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Tendencia Mensual */}
      <motion.div variants={cardVariants} initial="hidden" animate="visible" transition={{ delay: 0.8 }}>
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-green-600" />
              Tendencia Mensual de Averías
            </CardTitle>
            <CardDescription>
              Evolución del número de averías por mes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData.tendenciaAverias} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                  <XAxis 
                    dataKey="name"
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                  />
                  <YAxis 
                    tick={{ fontSize: 10 }}
                    tickLine={false}
                    label={{ 
                      value: 'Averías', 
                      angle: -90, 
                      position: 'insideLeft',
                      style: { textAnchor: 'middle', fontSize: 11 }
                    }}
                  />
                  <Tooltip 
                    formatter={(value: any) => [Number(value), 'Averías']}
                    wrapperStyle={{ fontSize: 11 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#72BF78" 
                    strokeWidth={3}
                    dot={{ fill: '#72BF78', strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, stroke: '#72BF78', strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
