
import { MainLayout } from '@/components/main-layout';
import { DashboardContent } from './_components/dashboard-content';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  return (
    <MainLayout>
      <DashboardContent />
    </MainLayout>
  );
}
