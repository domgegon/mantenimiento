
import { MainLayout } from '@/components/main-layout';
import { ReportesContent } from './_components/reportes-content';

export const dynamic = 'force-dynamic';

export default function ReportesPage() {
  return (
    <MainLayout>
      <ReportesContent />
    </MainLayout>
  );
}
