
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart,
  Search, 
  Filter,
  Download,
  MapPin,
  DollarSign,
  Calendar,
  Truck,
  AlertTriangle,
  TrendingUp,
  PieChart as PieChartIcon,
  FileText
} from 'lucide-react';
import { motion } from 'framer-motion';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';

interface Maquina {
  id: string;
  numeroSerie: string;
  marca: string;
  modelo: string;
  empresaAlquila: string;
  costeAlquiler: number;
  ubicacion: string;
  contrato: string | null;
  fechaRenovacion: string | null;
  fechaCreacion: string;
  _count?: {
    averias: number;
  };
}

interface Averia {
  id: string;
  fecha: string;
  tipoAveria: string;
  coste: number;
  descripcion: string;
  maquina: {
    numeroSerie: string;
    marca: string;
    ubicacion: string;
  };
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const marcas = ['Todas', 'Toyota', 'Jungheinrich', 'Still', 'Linde', 'Hyster', 'Crown', 'BT', 'Yale'];
const ubicaciones = ['Todas', 'Madrid - Coslada', 'Barcelona - Mercabarna', 'Valencia - Puerto', 'Sevilla - Centro', 'Zaragoza - Plaza', 'Bilbao - Zona Franca', 'Málaga - Guadalhorce', 'Murcia - Espinardo'];

export function ReportesContent() {
  const [maquinas, setMaquinas] = useState<Maquina[]>([]);
  const [averias, setAverias] = useState<Averia[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [marcaFilter, setMarcaFilter] = useState('Todas');
  const [ubicacionFilter, setUbicacionFilter] = useState('Todas');
  const [fechaDesde, setFechaDesde] = useState('');
  const [fechaHasta, setFechaHasta] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [maquinasResponse, averiasResponse] = await Promise.all([
        fetch('/api/inventario'),
        fetch('/api/averias')
      ]);

      if (maquinasResponse?.ok) {
        const maquinasData = await maquinasResponse?.json?.();
        setMaquinas(maquinasData?.maquinas || []);
      }

      if (averiasResponse?.ok) {
        const averiasData = await averiasResponse?.json?.();
        setAverias(averiasData?.averias || []);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Error al cargar los datos",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Filtrar datos
  const filteredMaquinas = maquinas?.filter?.(maquina => {
    if (searchTerm && !maquina?.numeroSerie?.toLowerCase?.()?.includes?.(searchTerm?.toLowerCase?.())) return false;
    if (marcaFilter && marcaFilter !== 'Todas' && maquina?.marca !== marcaFilter) return false;
    if (ubicacionFilter && ubicacionFilter !== 'Todas' && maquina?.ubicacion !== ubicacionFilter) return false;
    return true;
  }) || [];

  const filteredAverias = averias?.filter?.(averia => {
    if (fechaDesde && new Date(averia?.fecha) < new Date(fechaDesde)) return false;
    if (fechaHasta && new Date(averia?.fecha) > new Date(fechaHasta)) return false;
    if (marcaFilter && marcaFilter !== 'Todas' && averia?.maquina?.marca !== marcaFilter) return false;
    if (ubicacionFilter && ubicacionFilter !== 'Todas' && averia?.maquina?.ubicacion !== ubicacionFilter) return false;
    return true;
  }) || [];

  // Cálculos estadísticos
  const totalCostoAlquiler = filteredMaquinas?.reduce?.((sum, m) => sum + Number(m?.costeAlquiler || 0), 0) || 0;
  const totalCostoAverias = filteredAverias?.reduce?.((sum, a) => sum + Number(a?.coste || 0), 0) || 0;
  
  // Máquinas que renovaran en los próximos 30 días
  const hoy = new Date();
  const en30Dias = new Date();
  en30Dias.setDate(hoy.getDate() + 30);
  
  const proximasRenovaciones = filteredMaquinas?.filter?.(m => {
    if (!m?.fechaRenovacion) return false;
    const fechaRenovacion = new Date(m.fechaRenovacion);
    return fechaRenovacion >= hoy && fechaRenovacion <= en30Dias;
  }) || [];

  // Datos para gráficos
  const costosPorUbicacion = ubicaciones.filter(u => u !== 'Todas').map(ubicacion => {
    const maquinasUbicacion = filteredMaquinas?.filter?.(m => m?.ubicacion === ubicacion) || [];
    const averiasUbicacion = filteredAverias?.filter?.(a => a?.maquina?.ubicacion === ubicacion) || [];
    
    return {
      name: ubicacion?.replace?.(' - ', '\n') || ubicacion,
      alquiler: maquinasUbicacion?.reduce?.((sum, m) => sum + Number(m?.costeAlquiler || 0), 0) || 0,
      averias: averiasUbicacion?.reduce?.((sum, a) => sum + Number(a?.coste || 0), 0) || 0,
    };
  })?.filter?.(item => item?.alquiler > 0 || item?.averias > 0) || [];

  const maquinasPorMarca = marcas.filter(m => m !== 'Todas').map(marca => {
    const count = filteredMaquinas?.filter?.(m => m?.marca === marca)?.length || 0;
    return { name: marca, value: count };
  })?.filter?.(item => item?.value > 0) || [];

  const exportReport = () => {
    const headers = [
      'Resumen del Periodo',
      'Fecha Generación: ' + new Date().toLocaleDateString('es-ES'),
      '',
      'MÉTRICAS GENERALES',
      'Total Máquinas,' + filteredMaquinas?.length,
      'Costo Mensual Alquiler,€' + totalCostoAlquiler?.toLocaleString?.('es-ES'),
      'Costo Total Averías,€' + totalCostoAverias?.toLocaleString?.('es-ES'),
      'Próximas Renovaciones,' + proximasRenovaciones?.length,
      '',
      'DETALLE POR UBICACIÓN'
    ];

    const detailData = costosPorUbicacion?.map?.(item => [
      item?.name || '',
      '€' + item?.alquiler?.toLocaleString?.('es-ES'),
      '€' + item?.averias?.toLocaleString?.('es-ES')
    ]) || [];

    const csvContent = [
      ...headers,
      'Ubicación,Costo Alquiler,Costo Averías',
      ...detailData?.map?.(row => row?.join?.(',')) || []
    ]?.join?.('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window?.URL?.createObjectURL?.(blob);
    const a = document?.createElement?.('a');
    a.href = url;
    a.download = `reporte_detallado_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window?.URL?.revokeObjectURL?.(url);
  };

  if (loading) {
    return (
      <div className="p-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-64"></div>
          <div className="h-96 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6 bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="border-b pb-6"
      >
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-3">
              <BarChart className="w-8 h-8 text-blue-600" />
              Reportes Detallados
            </h1>
            <p className="text-gray-600">Análisis avanzado de costos, rendimiento y métricas clave</p>
          </div>
          <Button 
            className="bg-blue-600 hover:bg-blue-700"
            onClick={exportReport}
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar Reporte
          </Button>
        </div>
      </motion.div>

      {/* Filtros Avanzados */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtros Avanzados
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por número de serie..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e?.target?.value || '')}
                className="pl-10"
              />
            </div>

            <Select value={marcaFilter} onValueChange={setMarcaFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Marca" />
              </SelectTrigger>
              <SelectContent>
                {marcas?.map?.(marca => (
                  <SelectItem key={marca} value={marca || 'todas'}>
                    {marca}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={ubicacionFilter} onValueChange={setUbicacionFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Ubicación" />
              </SelectTrigger>
              <SelectContent>
                {ubicaciones?.map?.(ubicacion => (
                  <SelectItem key={ubicacion} value={ubicacion || 'todas'}>
                    {ubicacion}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Input
              type="date"
              placeholder="Fecha desde"
              value={fechaDesde}
              onChange={(e) => setFechaDesde(e?.target?.value || '')}
            />

            <Input
              type="date"
              placeholder="Fecha hasta"
              value={fechaHasta}
              onChange={(e) => setFechaHasta(e?.target?.value || '')}
            />
          </div>
        </CardContent>
      </Card>

      {/* Métricas Principales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Truck className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Máquinas</p>
                <p className="text-2xl font-bold">{filteredMaquinas?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Costo Mensual</p>
                <p className="text-2xl font-bold text-green-600">
                  €{totalCostoAlquiler?.toLocaleString?.('es-ES') || '0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Costo Averías</p>
                <p className="text-2xl font-bold text-red-600">
                  €{totalCostoAverias?.toLocaleString?.('es-ES') || '0'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Calendar className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Renovaciones Próximas</p>
                <p className="text-2xl font-bold text-orange-600">{proximasRenovaciones?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Costos por Ubicación</CardTitle>
            <CardDescription>Comparación de costos de alquiler vs averías por centro logístico</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={costosPorUbicacion}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" fontSize={12} />
                  <YAxis />
                  <Tooltip formatter={(value) => [`€${Number(value).toLocaleString('es-ES')}`, '']} />
                  <Legend />
                  <Bar dataKey="alquiler" fill="#10b981" name="Costo Alquiler" />
                  <Bar dataKey="averias" fill="#f59e0b" name="Costo Averías" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Distribución por Marca</CardTitle>
            <CardDescription>Número de máquinas por marca</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={maquinasPorMarca}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {maquinasPorMarca?.map?.((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS?.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Próximas Renovaciones */}
      {proximasRenovaciones?.length > 0 && (
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-orange-600" />
              Próximas Renovaciones (30 días)
            </CardTitle>
            <CardDescription>
              Contratos que requieren renovación en los próximos 30 días
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Número Serie</TableHead>
                    <TableHead>Marca</TableHead>
                    <TableHead>Ubicación</TableHead>
                    <TableHead>Contrato</TableHead>
                    <TableHead>Fecha Renovación</TableHead>
                    <TableHead>Días Restantes</TableHead>
                    <TableHead>Costo Mensual</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {proximasRenovaciones?.map?.((maquina) => {
                    const fechaRenovacion = new Date(maquina.fechaRenovacion!);
                    const diasRestantes = Math.ceil((fechaRenovacion.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24));
                    
                    return (
                      <TableRow key={maquina?.id}>
                        <TableCell className="font-medium">{maquina?.numeroSerie}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{maquina?.marca}</Badge>
                        </TableCell>
                        <TableCell className="text-sm">{maquina?.ubicacion}</TableCell>
                        <TableCell className="text-sm">{maquina?.contrato || '-'}</TableCell>
                        <TableCell className="text-sm">
                          {fechaRenovacion.toLocaleDateString('es-ES')}
                        </TableCell>
                        <TableCell>
                          <Badge variant={diasRestantes <= 7 ? "destructive" : "default"}>
                            {diasRestantes} días
                          </Badge>
                        </TableCell>
                        <TableCell className="font-semibold text-green-600">
                          €{Number(maquina?.costeAlquiler)?.toLocaleString?.('es-ES')}/mes
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
